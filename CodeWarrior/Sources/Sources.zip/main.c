#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "timer.h"
#include "lcd.h"



void main(void) {
  
  word distance;
  
  timer_init();
  LCDinit();
  
  LCDprintf("Hello World");
  
  sonic_init();


	EnableInterrupts;


  for(;;) {
      LCDclear();
      distance = sonic_getDistance();
      LCDprintf("Hello World!\n %d mm", distance);
      msleep(100);
  } 
}
